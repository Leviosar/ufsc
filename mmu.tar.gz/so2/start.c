#include "riscv.h"

void main();

typedef unsigned long uint64;

#define MPP_MASK (3L << 11)
#define MPP_SUPERVISOR_MODE (1L << 11)

void
start()
{
  // Set M Previous Privilege mode to Supervisor, for mret.
  unsigned long x = r_mstatus();
  x &= ~MSTATUS_MPP_MASK;
  x |= MSTATUS_MPP_S;
  w_mstatus(x);

  // Set M Exception Program Counter to main, for mret.
  w_mepc((uint64)main);

  // Disable paging for now.
  w_satp(0);

  // Switch to supervisor mode and jump to main().
  asm volatile("mret");
}
