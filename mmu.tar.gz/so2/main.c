#include "riscv.h"

#define SATP_SV39 (8L << 60)
#define MAKE_SATP(initaddr) (SATP_SV39 | (((uint64)initaddr) >> 12))

void turn_on_virtual_memory();

void
main()
{
  turn_on_virtual_memory();
}

void
turn_on_virtual_memory()
{
  w_satp(MAKE_SATP(HEAP_START));
  sfence_vma();
}
